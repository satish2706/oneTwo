package com.cg.banking.daoservices;

import java.util.List;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transactions;
import com.cg.banking.util.BankingDBUtil;

public class TransactionDAOImpl implements TransactionDAO {

	@Override
	public   Transactions save(long accountNo,Transactions transaction) {
		transaction.setTransactionId(BankingDBUtil.getTRANSACTION_ID());
		BankingDBUtil.account.get(accountNo).getTransactions().put(transaction.getTransactionId(),transaction);
		return transaction;
	}

	@Override
	public boolean update(Transactions transaction) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Transactions findOne(int transactionId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Transactions> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

}
