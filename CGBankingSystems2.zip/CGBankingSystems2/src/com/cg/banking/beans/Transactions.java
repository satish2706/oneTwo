package com.cg.banking.beans;

public class Transactions {
private int transactionId;
private float amount;
private String transactionType;
public Transactions() {}
public Transactions(float amount,String transactionType){
	super();
	this.amount=amount;
	this.transactionType=transactionType;
}
public Transactions(int transactionId,float amount,String transactionType){
	super();
	this.amount=transactionId;
	this.amount=amount;
	this.transactionType=transactionType;
}
public int getTransactionId() {
	return transactionId;
}
public void setTransactionId(int transactionId) {
	this.transactionId = transactionId;
}
public float getAmount() {
	return amount;
}
public void setAmount(float amount) {
	this.amount = amount;
}
@Override
public String toString() {
	return "Transactions [transactionId=" + transactionId + ", amount=" + amount + ", transactionType="
			+ transactionType + "]";
}
public String getTransactionType() {
	return transactionType;
}
public void setTransactionType(String transactionType) {
	this.transactionType = transactionType;
}
}
