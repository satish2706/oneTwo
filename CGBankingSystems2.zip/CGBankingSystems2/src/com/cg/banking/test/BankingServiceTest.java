package com.cg.banking.test;
import static org.junit.Assert.*;

import java.util.List;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import com.cg.banking.beans.*;
import com.cg.banking.daoservices.AccountDAO;
import com.cg.banking.daoservices.AccountDaoImpl;
import com.cg.banking.exceptions.*;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;
import com.cg.banking.util.BankingDBUtil;
public class BankingServiceTest {
private static BankingServices banking;
private static AccountDAO accountDao;
@BeforeClass
public static void setUpTestEnv() {
	banking = new BankingServicesImpl();
	accountDao=new AccountDaoImpl();
}

@Before
public void setUpTestData() {
    Account  account1 = new Account("Savings",1000);
    Account  account2 = new Account("Savings",1000);    
    BankingDBUtil.account.put(account1.getAccountNo(),account1);
    BankingDBUtil.account.put(account2.getAccountNo(),account2);
    BankingDBUtil.ACCOUNT_NUMBER = 2024017810;
}

@Test
public void testOpenAccountForValidData() throws InvalidAmountException, InvalidAccountTypeException, BankingServiceDownException {
	long expected_ACCOUNT_NUMBER=2024017811;
	long actual_ACCOUNT_NUMBER=banking.openAccount("Savings", 1000);
	assertEquals(expected_ACCOUNT_NUMBER, actual_ACCOUNT_NUMBER);
}

@Test
public void testDepositAmountForValidDate() throws AccountNotFoundException, BankingServiceDownException, AccountBlockedException {
	long expected_Account_Balance=1500;
	long actual_Account_Balance=(long)banking.depositAmount(2024017811,1000);
	assertEquals(expected_Account_Balance, actual_Account_Balance);
}
@Test
public void testwithDrawAmountForValidDate() throws AccountNotFoundException, BankingServiceDownException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberexception, InvalidAmountException, InvalidAccountTypeException {
	long expected_Account_Balance=500;
	long actual_ACCOUNT_NUMBER=banking.openAccount("Savings", 1000);
	Account account=accountDao.findOne(actual_ACCOUNT_NUMBER);
	long actual_Account_Balance=(long)banking.withdrawAmount(actual_ACCOUNT_NUMBER, 500,account.getPinNumber());
	assertEquals(expected_Account_Balance, actual_Account_Balance);
}

}
